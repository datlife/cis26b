/****************************************************************************
 
   Demonstration of the strtime function

****************************************************************************/
#include <stdio.h>
#include <time.h>

int main( void )
{
    struct tm *timeptr;
    time_t timeval;
    char buffer[80];

    time(&timeval);

    timeptr = localtime(&timeval);

    strftime(buffer, 80, "%c\n", timeptr);
    printf("strftime %%c format\n");
    printf("-------------------------\n %s\n", buffer);

    strftime(buffer, 80, "%A, %B %d, %H:%M\n", timeptr);
    printf("strftime %%A, %%B %%d, %%H:%%M format\n");
    printf("--------------------------------\n %s\n", buffer);

    strftime(buffer, 80, "%a, %b %d, %H:%M\n", timeptr);
    printf("strftime %%a, %%b %%d, %%H:%%M format\n");
    printf("--------------------------------\n %s\n", buffer);


    strftime(buffer, 80, "%a, %b %d, %I:%M %p\n", timeptr);
    printf("strftime %%a, %%b %%d, %%I:%%M %%p format\n");
    printf("-----------------------------------\n %s\n", buffer);

    strftime(buffer, 80, "%a, %b %d, %I:%M %p, %Y\n", timeptr);
    printf("strftime %%a, %%b %%d, %%I:%%M %%p, %%Y format\n");
    printf("---------------------------------------\n %s\n", buffer);

    strftime(buffer, 80, "%a, %b %d, %I:%M %p, %y\n", timeptr);
    printf("strftime %%a, %%b %%d, %%I:%%M %%p, %%y format\n");
    printf("---------------------------------------\n %s\n", buffer);

    strftime(buffer, 80, "%A, %b %d %I:%M %p %Y\n", timeptr);
    printf("strftime %%A, %%b %%d, %%I:%%M %%p, %%Y format\n");
    printf("---------------------------------------\n %s\n", buffer);


    return 0;
}

