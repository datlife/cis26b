/****************************************************************************
 
   Using the ANSI C Time Functions

****************************************************************************/
#include <stdio.h>
#include <time.h>

int main( void )
{
    struct tm *timeptr; // Notice lack of allocation
    time_t timeval;
    char *chtime;       // No space allocation again!

    time(&timeval);     // seconds since 1/1/70
    printf("%ld\n", timeval);

    timeval = time(NULL);
    printf("%ld\n", timeval);

    timeptr = localtime(&timeval);
    printf("Local time: %d hours, %d minutes\n\n", 
        timeptr->tm_hour,
        timeptr->tm_min);

    timeptr = gmtime(&timeval);
    printf("Greenwich time: %d hours, %d minutes\n\n", 
        timeptr->tm_hour,
        timeptr->tm_min);

    chtime = asctime(timeptr);
    printf("Greenwich ASCII time from asctime: %s\n\n", chtime);

    timeptr = localtime(&timeval);
    chtime = asctime(timeptr);  
    printf("Local ASCII time from asctime: %s\n\n", chtime);

    // asctime takes a struct tm pointer
    // ctime takes a time_t pointer

    chtime = ctime(&timeval);
    printf("Local ASCII time from ctime: %s\n\n", chtime);
    
    return 0;
}

