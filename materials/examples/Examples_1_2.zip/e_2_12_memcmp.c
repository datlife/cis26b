/***************************************************
    Example 2.12

    Comparing arrays: memcmp (similar to strcmp)

/***************************************************/

#include <stdio.h>
#include <string.h>

int main (void)
{
    int a[10] = {10, 20, 30, 90, 50};
    //int b[10] = {10, 20, 30, 90, 50};
    //int b[10] = {10, 20, 50, 90, 50};
    int b[10] = {10, 20, 5, 90, 50};

    //printf("%d", memcmp(a, b, 10 * sizeof (int)));
    printf("%d", memcmp(a, b, 2 * sizeof (int)));
    return 0;
}
