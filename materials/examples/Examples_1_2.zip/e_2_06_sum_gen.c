/***************************************************
    Example 2.6

    A generalized array sum function with
    pointer arithmetic

/***************************************************/

#include <stdio.h>
#define MAX 10

int main (void)
{
    int sumints(int *pi, int num_elements);
    int a[MAX] = {20, 30, 10, -50, 30};
    int n = 5;

    printf("Sum = %d\n", sumints(a, n));

    return 0;
}

/***************************************************
    Sums the elements of an int array; it stops at
    the first 0
*/
int sumints(int *pi, int num_elements)
{
    int sum = 0;

    while (num_elements-- > 0)
    {
        sum += *pi++;
    }
    return sum;
}
