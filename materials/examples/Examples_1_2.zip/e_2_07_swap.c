/***************************************************
    Example 2.7

    A swap function that fails because of
    call by value

/***************************************************/

#include <stdio.h>

int main (void)
{
    void swap(int i, int j);
    int a = 10, b = 15;

    printf("a = %d  b = %d\n", a, b);
    swap(a, b);
    printf("a = %d  b = %d\n", a, b);

    return 0;
}

/***************************************************
    Incorrect swap
*/
void swap(int i, int j)
{
    int temp;

    temp = i;
    i    = j;
    j    = temp;
    return;
}
