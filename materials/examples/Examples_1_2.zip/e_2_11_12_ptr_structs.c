/***************************************************
    Example 2.11 & Example 2.12

    Summing key values of structs using
    pointer arithmetic

    Initializing an array of strucs at declaration
    time

/***************************************************/

#include <stdio.h>

struct book{
	char   ISBN[15];
	char  *author;
	int    year;
    double price;
};

int main (void)
{
    int sum(struct book *plist, int num_books);
    struct book list[10] =
    {
        {"0170088219", "Ron House", 1994, 98.75},
        {"0534951406", "John W. Perry", 1998, 50.99},
        {"0131103628", "Dennis M.Ritchie", 1988, 45.50},
    };
    int num_books = 3;
    double total;

    total = sum(list, num_books);
    printf("Sum = %.2lf", total);

    return 0;
}

/***************************************************
    Calculate total price
*/
int sum(struct book *plist, int num_books)
{
    double total = 0;

    while (num_books-- > 0)
    {
        total += plist->price;
        plist++;
    }

    return total;
}
