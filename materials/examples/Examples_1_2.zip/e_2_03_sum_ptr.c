/***************************************************
    Example 2.3
    
    Typical traversal of a non-char array with a 
    pointer


/***************************************************/ 

#include <stdio.h>
#define MAX 10

int main (void)
{
    int sumints(int *pi);
    int a[MAX + 1] = {20, 30, 10, -50, 30}; 
             // ^ there is at least one 0 in the list!
                
    printf("Sum = %d\n", sumints(a));
    
    return 0;
}

/***************************************************
    Sums the elements of an int array; it stops at
    the first 0
*/ 
int sumints(int *pi)
{
    int sum = 0;

    //while (*pi != 0) 
    while (*pi) 
    {
        sum += *pi++;
    }
    return sum;
}
