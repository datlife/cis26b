/***************************************************
    Example 2.9

    Dysfunctional attempt to swap structs
    in a function

/***************************************************/

#include <stdio.h>

struct date{
    int month;
    int day;
    int year;
};

int main (void)
{
    void swap(struct date d1, struct date d2);
    struct date date1 = {4, 12, 2011};
    struct date date2 = {3, 13, 2011};

    printf("%02d/%02d/%02d\n", date1.month, date1.day, date1.year);
    printf("%02d/%02d/%02d\n\n", date2.month, date2.day, date2.year);
    swap(date1, date2);
    printf("%02d/%02d/%02d\n", date1.month, date1.day, date1.year);
    printf("%02d/%02d/%02d\n\n", date2.month, date2.day, date2.year);

    return 0;
}

/***************************************************
    Incorrect swap
*/
void swap(struct date d1, struct date d2)
{
    struct date temp;

    temp = d1;
    d1   = d2;
    d2   = temp;
    return;
}
