/***************************************************
    Example 2.14

    A first exposure to code using pointers to
    pointers

/***************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void)
{
    void strswap(char **s1, char **s2);
    char *p1 = "Hello";
    char *p2 = "Goodbye";
    char *s1, *s2;

    if ((s1 = (char *) malloc(strlen(p1) + 1)) == NULL ||
        (s2 = (char *) malloc(strlen(p2) + 1)) == NULL)
    {
        printf("Fatal memory error!\n");
        exit(1);
    }

    strcpy(s1, p1);
    strcpy(s2, p2);
    printf("s1 is \"%s\", s2 is \"%s\".\n", s1, s2);
    strswap(&s1, &s2);
    printf("s1 is now \"%s\", s2 is now \"%s\".\n", s1, s2);

    return 0;
}

/*****************************************************
   swap strings
*/
void strswap(char **s1, char **s2)
{
    char *temp;

    temp = *s1;
    *s1  = *s2;
    *s2  = temp;

    return;
}
