/***************************************************
    Example 2.12

    Copying array of other type than char: memcpy
                               (similar to strcpy)

/***************************************************/

#include <stdio.h>
#include <string.h>

int main (void)
{
    int a[10] = {10, 10, 10, 999, 999, 999};
    int i, c[10], d[10];

    //memcpy(c, a, 3 * sizeof (int));
    memcpy(c, a, 10 * sizeof (int));

    for (i = 0; i < 10; i++)
    {
        printf("%3d %3d\n", a[i], c[i]);
    }
    putchar('\n');

    memcpy(d, a + 3, 3 * sizeof (int));
    memcpy(d + 3, a + 1, 3 * sizeof (int));

    for (i = 0; i < 10; i++)
    {
        printf("%3d %3d\n", a[i], d[i]);
    }
    putchar('\n');

    return 0;
}
