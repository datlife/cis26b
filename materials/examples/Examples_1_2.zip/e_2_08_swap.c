/***************************************************
    Example 2.8

    A swap function that works: using pointers

/***************************************************/

#include <stdio.h>

int main (void)
{
    void swap(int *pi, int *pj);
    int a = 10, b = 15;

    printf("a = %d  b = %d\n", a, b);
    swap(&a, &b);
    printf("a = %d  b = %d\n", a, b);

    return 0;
}

/***************************************************
    swap
*/
void swap(int *pi, int *pj)
{
    int temp;

    temp = *pi;
    *pi  = *pj;
    *pj  = temp;
    return;
}
