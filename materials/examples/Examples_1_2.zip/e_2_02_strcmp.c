/***************************************************
    Example 2.2
    
    Demonstrate the use of a pointer to traverse a
    character array: 
    The insides of the ANSI C strcmp function.

/***************************************************/ 

#include <stdio.h>

int main (void)
{
    int strcmp(char *s1, char *s2);
    char name1[31] = "Andrew";
    char name2[31] = "Andra";
    //char name1[31] = "Andra";
    int cmp;
    char sign;
            
    cmp = strcmp(name1, name2);
    /*
    if (!cmp)
        sign = '=';
    else if (cmp > 0)
        sign = '>';
    else sign = '<';
    */

    /*
    if (!cmp)
        sign = '=';
    else
        sign = cmp > 0 ? '>' : '<';
    */

    sign = !cmp ? '=' : cmp > 0 ? '>' : '<';
    printf("\"%s\"  %c \"%s\"\n", name1, sign, name2);
    printf("\t\t--> The strcmp function returns %d\n\n", cmp);
    

    cmp = strcmp(name2, name1);
    sign = !cmp ? '=' : cmp > 0 ? '>' : '<';
    printf("\"%s\"  %c \"%s\"\n", name2, sign, name1);
    printf("\t\t--> The strcmp function returns %d\n\n", cmp);
    
    return 0;
}

/***************************************************
    Compares two strings and returns 
       --> 0 - if the two strings are identical
       --> a positive number - if the first parameter
           is greater than the second parameter
       --> a negative number - if the first parameter
           is less than the second parameter
*/ 
int strcmp(char *s1, char *s2)
{
    while (*s1 == *s2) 
    {
        if (*s1 == '\0') return 0;
        s1++;
        s2++;
    }
    return *s1 - *s2;
}
