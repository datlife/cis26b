/***************************************************
    Example 2.13

    Reversing a string in place:
    Get string from user, clean out white spaces and
    convert letters to lowercase, reverse string
    and then output to screen.

/***************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main (void)
{
    void getword(char *);
    void format(char *);
    void reverse(char *);
    char word[512];

    while (getword(word), format(word), strcmp(word, "quit"))
    {
        if (*word == '\0') continue;
        reverse(word);
        printf("Your original word reversed is \"%s\"\n\n", word );
    }

    return 0;
}

/*****************************************************
   Get user-entered string from terminal
*/
void getword(char *s)
{
    printf("Please enter a string: ");
    gets(s);
    return;
}

/*****************************************************
   Remove whitespace from string.
   Convert uppercase letters to lowercase.
*/
void format(char *s)
{
    char *fast = s, *slow = s;

    while (*fast)
    {
        if (!isspace(*fast))  *slow++ = tolower(*fast);
        fast++;
    }
    *slow = '\0';
}

/*****************************************************
   Reverse order of characters in string
*/
void reverse(char *s)
{
    char *end, *start = s, temp;

    if (*s == '\0') return;
    end = s + strlen(s) - 1;
    while (end > start)
    {
        temp   = *end;
        *end   = *start;
        *start = temp;
        start++;
        end--;
    }
}

