/***************************************************
    Example 2.5

    A horrible mixture of pointer arithmetic and
    array indexing

/***************************************************/

#include <stdio.h>
#define MAX 10

int main (void)
{
    int sumints(int list[]);
    int a[MAX + 1] = {20, 30, 10, -50, 30};
             // ^ there is at least one 0 in the list!

    printf("Sum = %d\n", sumints(a));

    return 0;
}

/***************************************************
    Sums the elements of an int array; it stops at
    the first 0
*/
int sumints(int list[])
{
    int sum = 0, j = 0;

    //while (list[j] != 0)
    while (*(list + j))
    {
        sum += *(list + j);
        j++;
    }
    return sum;
}
