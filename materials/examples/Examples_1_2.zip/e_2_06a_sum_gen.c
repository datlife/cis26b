/***************************************************
    Example 2.6a

    A generalized array sum function with
    pointer arithmetic

/***************************************************/

#include <stdio.h>
#define MAX 10

int main (void)
{
    int sumints(int *pi, int *pend);
    int a[MAX] = {20, 30, 10, -50, 30};
    int n = 5;

    printf("Sum = %d\n", sumints(a, a + n));

    return 0;
}

/***************************************************
    Sums the elements of an int array; it stops at
    the first 0
*/
int sumints(int *pi, int *pend)
{
    int sum = 0;

    while (pi < pend)
    {
        sum += *pi++;
    }
    return sum;
}
