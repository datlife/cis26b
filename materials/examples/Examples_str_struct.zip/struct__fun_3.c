/********************************
     CIS26B
     Complex Structures and Functions
        - define and initialize an array of FRIEND structures
        - use structures as reference parameters (pointers)
*/
#include <stdio.h>
#include <string.h>

typedef struct{
    char *name;
    char  phone[11];
    int   age;
} FRIEND;

void exchange( FRIEND *one, FRIEND *two );
void print_a_friend( FRIEND *a_friend );

int main( void )
{
    int i;

    FRIEND a_friend = { "John", "4081112345", 25 };
    FRIEND another_friend; 
    FRIEND friends[10] = 
    {
        { "John", "4081112345", 25 },
        { "Mary", "4089992222", 21 },
        { "Mira", "4086668888", 22 }
    };
    
    another_friend.name = "Mary";
    strcpy(another_friend.phone, "4089992222"); 
    another_friend.age = 21;

    printf( "%s %s %d\n", a_friend.name, a_friend.phone, a_friend.age );
    printf( "%s %s %d\n", another_friend.name, another_friend.phone, another_friend.age );
    printf( "\n" );

    for( i = 0; i < 3; i++ )
        print_a_friend( &friends[i] );
    printf( "\n" );

    exchange( &friends[0], &friends[2] );

    for( i = 0; i < 3; i++ )
        print_a_friend( &friends[i] );
    printf( "\n" );

	return 0;
}

/* ============================================ */
void exchange( FRIEND *one, FRIEND *two )
{
    FRIEND temp;

    temp = *one;
    *one = *two;
    *two = temp;
}

/* ============================================ */
void print_a_friend( FRIEND *a_friend )
{
    printf( "%s %s %d\n", a_friend->name, a_friend->phone, a_friend->age );
}

/************* OUTPUT *****************

 John 4081112345 25
 Mary 4089992222 21
 
 John 4081112345 25
 Mary 4089992222 21
 Mira 4086668888 22
 
 Mira 4086668888 22
 Mary 4089992222 21
 John 4081112345 25

*/