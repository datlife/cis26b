/********************************
    CIS26B
	Structures and Functions
	
	  - passing structures by value
	  - returning a structure from a function

    Example: Determine the middle of a segment in a plane.
 */

#include <stdio.h>

typedef struct{
    double x;
    double y;
} POINT;


POINT calcMiddle( POINT a, POINT b );

int main( void )
{
	POINT  a = { 4, 2 };
	POINT  b = { 1, 5 };
	POINT  m;
	   
	m = calcMiddle( a, b );
    printf( "x = %.2f\ny = %.2f\n", m.x, m.y );

	return 0;
}

/* =================== calcMiddle =================== 
   This function calculates the coordinates of the point 
   located in the middle of a segment in a plane.
     PRE:  a, b - points in a plane
     POST: the point in the middle calculated and returned
*/
POINT calcMiddle( POINT a, POINT b )
{

	POINT m;

    m.x = (a.x + b.x)/2;
	m.y = (a.y + b.y)/2;  

	return m;
}
/******** OUTPUT **********
 
 x = 2.50
 y = 3.50

*/

 
