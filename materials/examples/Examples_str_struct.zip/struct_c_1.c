/********************************
    CIS26B
	Complex Structure Definitions: reading, writing

    Example:
	  - a structure with four fields: 
            name - a string of size 21
            quiz - an array of 5 quiz scores // <=== an array as a field in a struct
            avescore - a double
            grade - char
 */

#include <stdio.h>

#define FLUSH while( getchar() != '\n' )

typedef struct {
		char   last_name[21];
		int    quiz[5];
		double avescore;
		char   grade;
} STU;


int main( void )
{
	STU s;
	int i;
	
    printf( "Enter student information:\n");
	printf( "\tLast name: " );
	scanf ( "%20s", s.last_name );
	FLUSH;
	printf( "\tQuiz 1 to Quiz5 scores: " );
	scanf ( "%d%d%d%d%d", &s.quiz[0], 
						 &s.quiz[1],
						 &s.quiz[2],
						 &s.quiz[3],
						 &s.quiz[4] );

	s.avescore = ( s.quiz[0] +	s.quiz[1] + s.quiz[2] +	
				   s.quiz[3] +  s.quiz[4] ) / 5.0;

	s.grade = 'A';

	/* a better way to write this fragment of code would be to 
	use a loop to read the quizzes; also a loop could have been 
	used to calculate the average */

	printf( "\n\nOUTPUT:\n" );

    printf( "\t\t Last name: %s\n", s.last_name );
	
	printf ( "\t\t Quizzes: " );
	for( i = 0; i < 5; i++ )
		printf( "%3d", s.quiz[i] );
	printf( "\n" );
	printf ( "\t\t Average: %.2f\n", s.avescore );
	printf ( "\t\t Grade: %c\n", s.grade );
		
	return 0;
}
/******** OUTPUT *********
 Enter student information:
	Last name: Leiserson
	Quiz 1 to Quiz5 scores: 10 9 8 10 7
 
 
 OUTPUT:
 Last name: Leiserson
 Quizzes:  10  9  8 10  7
 Average: 8.80
 Grade: A
*/