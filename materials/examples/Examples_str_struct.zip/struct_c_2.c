/********************************
 CIS26B
	Complex Structure Definitions 
 
    Example:
	  - writing an array of complex structures			  
*/

#include <stdio.h>

#define MAX 50 

typedef struct {
		char   last_name[21];
		int    quiz[5];
		double avescore;
		char   grade;
} STU;


void writeStuInfo( STU sAry[], int size );

int main( void )
{
	int size = 3;
	STU sAry[MAX] = 
	{ 
		{"Black", {7,  9, 9, 8,  7}, 8, 'B' },
		{"Lee",   {8, 10, 9, 8, 10}, 9, 'A' },
		{"Tran",  {7,  7, 7, 7,  7}, 7, 'C' }
	};
    	
	writeStuInfo( sAry, size );

	return 0;
}

/* =================== writeStuInfo =================== 
   This function prints an array of students
     PRE:  sAry, size
     POST: array printed
*/
void writeStuInfo( STU sAry[], int size )
{
  int s, q; // student and quiz indices

  for( s = 0; s < size; s++ )
  {
     printf( "%-20s", sAry[s].last_name );
	 for( q = 0; q < 5; q++ )
		 printf( "\t%3d", sAry[s].quiz[q]  );
	  
	 printf( "\t%5.2f", sAry[s].avescore );
	 printf( "\t%c\n", sAry[s].grade    );
  }
}
/******** OUTPUT ************
 
 Black               	  7	  9	  9	  8	  7	 8.00	B
 Lee                 	  8	 10	  9	  8	 10	 9.00	A
 Tran                	  7	  7	  7	  7	  7	 7.00	C
 
*/
