/********************************
     CIS26B
     Complex Structure Definitions: nested structures and pointers

     Example:
	    - writing one such structure
*/

#include <stdio.h>

#define MAX 50 

typedef struct {
		int month;
		int day;
		int year;
} DATE;
	

typedef struct {
		char   name[21];
		DATE   bdate;
		double avescore;
		char   grade;
} STU;


void writeStu( STU *pStu );

int main( void )
{
	STU a_student = { "Lee", { 10, 4, 1970 }, 88.52, 'B' };

    	
	writeStu( &a_student );

	return 0;
}

/* =================== writeStu =================== 
   This function prints the info for one student
     PRE:  stu
     POST: all of the fields printed
*/

void writeStu( STU *pStu )
{
	printf( "\tName: %-20s\n", pStu->name );
	printf( "\tBirth date: %d-%d-%d\n", 
		pStu->bdate.month, 
		pStu->bdate.day, 
		pStu->bdate.year ); 
	printf( "\tAverage: %.2f\n", pStu->avescore );
	printf( "\tGrade: %c\n\n", pStu->grade );

    return;
}
/************* OUTPUT *******************
 
	Name: Lee
	Birth date: 10-4-1970
	Average: 88.52
	Grade: B
 
 */