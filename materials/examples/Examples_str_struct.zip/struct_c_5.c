/********************************
     CIS26B
     Complex Structure Definitions: nested structures,
                                    pointers, and
								 arrays
    Example:
	  - writing an array of nested structures reusing 
	  the function defined in a previous example
*/

#include <stdio.h>

#define MAX 50 

typedef struct {
		int month;
		int day;
		int year;
} DATE;

typedef struct {
		char   name[21];
		DATE   bdate;
		double avescore;
		char   grade;
} STU;

void writeStu( const STU *pStu );
void writeStuInfo( const STU stuAry[], int size );

int main( void )
{
	int size = 3;
	STU sAry[MAX] = 
	{ 
		{"Black", { 11, 22, 1980 }, 99.95, 'A' },
		{"Lee",   { 10,  4, 1970 }, 88.52, 'B' },
		{"Tran",  { 12,  7, 1065 }, 85.82, 'B' }
	};
    	
	writeStuInfo( sAry, size );

	return 0;
}

/* =================== writeStuInfo =================== 
   This function prints an array of students
     PRE:  sAry, size
     POST: array printed
*/

void writeStuInfo( const STU sAry[], int size )
{
  int stuNdx;
  
  for( stuNdx = 0; stuNdx < size; stuNdx++ )
	  writeStu( &sAry[stuNdx] );

  return ;
}

/* =================== writeStu =================== 
   This function prints the info for one student
     PRE:  stu
     POST: all of the fields printed
*/

void writeStu( const STU *pStu )
{
	printf( "\tName: %-20s\n", pStu->name );
	printf( "\tBirth date: %d-%d-%d\n", 
		pStu->bdate.month, 
		pStu->bdate.day, 
		pStu->bdate.year ); 
	printf( "\tAverage: %.2f\n", pStu->avescore );
	printf( "\tGrade: %c\n\n", pStu->grade );

  return;
}

/*********** OUTPUT *************

	Name: Black
	Birth date: 11-22-1980
	Average: 99.95
	Grade: A
 
	Name: Lee
	Birth date: 10-4-1970
	Average: 88.52
	Grade: B
 
	Name: Tran
	Birth date: 12-7-1065
	Average: 85.82
	Grade: B
 

*/