/********************************
     CIS26B
     Complex Structure Definitions: nested structures
 
     Example:
         - writing one such structure
 */

#include <stdio.h>

typedef struct {
    int month;
    int day;
    int year;
} DATE;

typedef struct {
    char   name[21];
    DATE   bdate;   // <=== a struct as a field in another struct
    double avescore;
    char   grade;
} STU;


void writeStu( STU stu );

int main( void )
{
   
    STU s = { "Lee", { 10, 4, 1970 }, 88.52, 'B' };

    
    writeStu( s );
    
    return 0;
}

/* =================== writeStu ===================
 This function prints the info for one student
 PRE:  stu
 POST: all of the fields printed
 */

void writeStu( STU stu )
{
    printf( "\tName: %-20s\n", stu.name );
    printf( "\tBirth date: %d-%d-%d\n",
           stu.bdate.month,
           stu.bdate.day,
           stu.bdate.year );
    printf( "\tAverage: %.2f\n", stu.avescore );
    printf( "\tGrade: %c\n\n", stu.grade );
}

/************ OUTPUT **************
 
	Name: Lee
	Birth date: 10-4-1970
	Average: 88.52
	Grade: B
 
 */