/********************************
    CIS26B 
    Structures and Functions
	  - passing structures by value

    Example: Calculate the distance between two points 
	         in a plane. 
*/

#include <stdio.h>
#include <math.h>

typedef struct{
    double x;
    double y;
} POINT;


double calcDistance( POINT a, POINT b );

int main( void )
{
	POINT  a = { 4, 2 };
	POINT  b = { 1, 5 };
	double dist;
	
	dist = calcDistance( a, b );
    printf( "distance = %.2f\n", dist );

	return 0;
}

/* =================== calcDistance =================== 
   This function calculates the distance between two 
   points in a plane.
     PRE:  a, b - points in a plane
     POST: distance between a and b returned
*/
double calcDistance( POINT a, POINT b )
{
    double dist;
	double dx;
	double dy;

    dx   = a.x - b.x;
	dy   = a.y - b.y;  
	dist = sqrt( dx * dx + dy * dy );

	return dist;
}

/****** OUTPUT ******
 
 distance = 4.24

*/
