/****************************************************************************

   Demonstration of the assert function

****************************************************************************/
#include <assert.h>

int main( void )
{
    int i = 5;

    assert( i == 5);
    //assert( i == 2);

    return 0;
}
