/*********************************************************
   CIS 26B -  Advanced C Programming
   Write a function named findMax that finds the maximum of
   any number of integer arguments.

   Extra Credit:
/*********************************************************/

#include <stdio.h>



int main(void)
{
    printf("The largest is: %d\n", findMax(3, 20, 90, 10));
    printf("The largest is: %d\n", findMax(4, 20, 10, 50, 30));
    printf("The largest is: %d\n", findMax(2, 20, 10));
    printf("The largest is: %d\n", findMax(1, 13));
    printf("The largest is: %d\n", findMax(5, -20, 10, -50, -30, -90));

    return 0;
}
